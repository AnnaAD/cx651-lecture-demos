#include <stdio.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <sys/socket.h>

#define N 2

struct request {
  int A[N * N];
  int B[N * N];
};

struct response {
  int C[N * N];
};

int main() {
    int sock_fd = socket(AF_INET, SOCK_DGRAM, 0);

    struct sockaddr_in server_addr = {0};
    server_addr.sin_family = AF_INET;
    server_addr.sin_port = htons(8080);
    inet_pton(AF_INET, "127.0.0.1", &server_addr.sin_addr);

    struct request req;
    printf("A: ");
    for (int i = 0; i < N * N; i++) scanf("%d", &req.A[i]);
    printf("B: ");
    for (int i = 0; i < N * N; i++) scanf("%d", &req.B[i]);

    sendto(sock_fd, &req, sizeof(req), 0, (struct sockaddr *)&server_addr, sizeof(server_addr));

    struct response res;
    recvfrom(sock_fd, &res, sizeof(res), 0, NULL, NULL);

    for (int i = 0; i < N * N; i++) printf("%d%c", res.C[i], i % N == N - 1 ? '\n' : ' ');

    close(sock_fd);
    return 0;
}
